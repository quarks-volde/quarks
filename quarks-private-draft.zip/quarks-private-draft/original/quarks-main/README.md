Ocean-Atmospheric Research
